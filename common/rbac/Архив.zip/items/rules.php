<?php
return [
    'profileOwner' => 'O:34:"common\\rbac\\rules\\ProfileOwnerRule":3:{s:4:"name";s:12:"profileOwner";s:9:"createdAt";N;s:9:"updatedAt";N;}',
    'postAuthor' => 'O:32:"common\\rbac\\rules\\PostAuthorRule":3:{s:4:"name";s:10:"postAuthor";s:9:"createdAt";N;s:9:"updatedAt";N;}',
];
