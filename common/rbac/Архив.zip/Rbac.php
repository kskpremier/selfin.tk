<?php

namespace common\rbac;

class Rbac
{
    const MANAGE_DOORLOCK = 'manageDoorLock';
//    const MANAGE_ = 'managePost';
}