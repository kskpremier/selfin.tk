<?php

namespace backend\modules\faces;

/**
 * Facematica module definition class
 */
class FaceRecognition extends \yii\base\Module
{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'backend\modules\faces\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
