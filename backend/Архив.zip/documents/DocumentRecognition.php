<?php

namespace backend\modules\documents;

/**
 * OCR module definition class
 */
class DocumentRecognition extends \yii\base\Module
{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'backend\modules\documents\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
